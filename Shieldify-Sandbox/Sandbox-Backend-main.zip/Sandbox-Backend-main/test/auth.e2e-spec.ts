import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from './../src/app.module';

describe('Authentication System (e2e)', () => {
  let app: INestApplication;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/auth/signup (POST)', () => {
    return request(app.getHttpServer())
      .post('/auth/signup')
      .send({ email: 'test@example.com', password: 'password123', username: 'testuser' })
      .expect(201)
      .expect(res => {
        expect(res.body).toHaveProperty('id');
        expect(res.body.email).toBe('test@example.com');
      });
  });

  it('/auth/signin (POST)', () => {
    return request(app.getHttpServer())
      .post('/auth/signin')
      .send({ email: 'test@example.com', password: 'password123' })
      .expect(200)
      .expect(res => {
        expect(res.body).toHaveProperty('access_token');
      });
  });

  it('/auth/signout (POST)', async () => {
    // First, sign in to get the access token
    const signinResponse = await request(app.getHttpServer())
      .post('/auth/signin')
      .send({ email: 'test@example.com', password: 'password123' });

    const token = signinResponse.body.access_token;

    // Then, use the token to sign out
    return request(app.getHttpServer())
      .post('/auth/signout')
      .set('Authorization', `Bearer ${token}`)
      .expect(200)
      .expect({ message: 'Signed out successfully' });
  });

  afterAll(async () => {
    await app.close();
  });
});