import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';
import { AuthService } from '../src/auth/auth.service';
import { UserService } from '../src/user/user.service';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Mock the UserService
const mockUserService = {
  findByUserId: jest.fn(),
  create: jest.fn(),
};

// Mock the SupabaseClient
const mockSupabaseClient = {
  auth: {
    getUser: jest.fn(),
  },
};

jest.mock('@supabase/supabase-js', () => ({
  createClient: jest.fn(() => mockSupabaseClient),
}));

describe('AuthService', () => {
  let authService: AuthService;
  let userService: UserService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        {
          provide: ConfigService,
          useValue: {
            get: jest.fn((key: string) => {
              if (key === 'SUPABASE_URL') return 'https://example.supabase.co';
              if (key === 'SUPABASE_KEY') return 'mock-key';
              return null;
            }),
          },
        },
        {
          provide: UserService,
          useValue: mockUserService,
        },
      ],
    }).compile();

    authService = module.get<AuthService>(AuthService);
    userService = module.get<UserService>(UserService);
  });

  it('should be defined', () => {
    expect(authService).toBeDefined();
  });

  describe('handleOAuthCallback', () => {
    it('should create a new user if not exists', async () => {
      const mockUser = {
        id: 'user123',
        email: 'test@example.com',
        user_metadata: { full_name: 'Test User' },
      };

      mockSupabaseClient.auth.getUser.mockResolvedValue({ data: { user: mockUser }, error: null });
      mockUserService.findByUserId.mockResolvedValue(null);
      mockUserService.create.mockResolvedValue({ ...mockUser, username: 'Test User' });

      const result = await authService.handleOAuthCallback('mock-token');

      expect(mockSupabaseClient.auth.getUser).toHaveBeenCalledWith('mock-token');
      expect(mockUserService.findByUserId).toHaveBeenCalledWith('user123');
      expect(mockUserService.create).toHaveBeenCalledWith({
        user_id: 'user123',
        email: 'test@example.com',
        username: 'Test User',
        password: expect.any(String),
      });
      expect(result).toEqual(mockUser);
    });

    it('should return existing user if already exists', async () => {
      const mockUser = {
        id: 'user123',
        email: 'test@example.com',
        user_metadata: { full_name: 'Test User' },
      };

      mockSupabaseClient.auth.getUser.mockResolvedValue({ data: { user: mockUser }, error: null });
      mockUserService.findByUserId.mockResolvedValue({ ...mockUser, username: 'Test User' });

      const result = await authService.handleOAuthCallback('mock-token');

      expect(mockSupabaseClient.auth.getUser).toHaveBeenCalledWith('mock-token');
      expect(mockUserService.findByUserId).toHaveBeenCalledWith('user123');
      expect(mockUserService.create).not.toHaveBeenCalled();
      expect(result).toEqual(mockUser);
    });

    it('should throw an error if getUser fails', async () => {
      mockSupabaseClient.auth.getUser.mockResolvedValue({ data: { user: null }, error: new Error('Auth error') });

      await expect(authService.handleOAuthCallback('mock-token')).rejects.toThrow('OAuth callback handling failed: Auth error');
    });

    it('should throw an error if user is not found', async () => {
      mockSupabaseClient.auth.getUser.mockResolvedValue({ data: { user: null }, error: null });

      await expect(authService.handleOAuthCallback('mock-token')).rejects.toThrow('OAuth callback handling failed: User not found');
    });
  });
});