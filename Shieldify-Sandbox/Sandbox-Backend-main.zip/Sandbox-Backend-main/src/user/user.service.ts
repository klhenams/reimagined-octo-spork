import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { IUser } from './interfaces/user.interface';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';

@Injectable()
export class UserService {
  private supabase: SupabaseClient;
  private jwtSecret: string;

  constructor(private configService: ConfigService) {
    const supabaseUrl = this.configService.get<string>('SUPABASE_URL');
    const supabaseKey = this.configService.get<string>('SUPABASE_KEY');
    this.jwtSecret = this.configService.get<string>('JWT_SECRET');

    if (!supabaseUrl || !supabaseKey || !this.jwtSecret) {
      throw new Error('Supabase URL, API key, or JWT secret is missing');
    }

    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  async create(createUserDto: CreateUserDto): Promise<IUser> {
    const hashedPassword = await bcrypt.hash(createUserDto.password, 10);
    const userToCreate = { ...createUserDto, password: hashedPassword };

    const { data, error } = await this.supabase
      .from('User')
      .insert(userToCreate)
      .single();

    if (error) throw error;
    return data as IUser;
  }

  async findAll(): Promise<IUser[]> {
    const { data, error } = await this.supabase
      .from('User')
      .select('*');

    if (error) throw error;
    return data as IUser[];
  }

  async findOneByToken(token: string): Promise<IUser> {
    const decoded = jwt.verify(token, this.jwtSecret) as { user_id: string };
    const user_id = decoded.user_id;

    const { data, error } = await this.supabase
      .from('User')
      .select('*')
      .eq('user_id', user_id)
      .single();

    if (error) throw error;
    return data as IUser;
  }


  async update(user_id: string, updateUserDto: UpdateUserDto): Promise<IUser> {
    let updateValue = updateUserDto.value;

    if (updateUserDto.field === 'password') {
      updateValue = await bcrypt.hash(updateUserDto.value, 10);
    }

    const { data, error } = await this.supabase
      .from('User')
      .update({ [updateUserDto.field]: updateValue })
      .eq('user_id', user_id)
      .single();

    if (error) throw error;

    // Send confirmation email if email is updated
    if (updateUserDto.field === 'email') {
      await this.sendConfirmationEmail(updateUserDto.value);
    }

    return data as IUser;
  }


  async remove(user_id: string): Promise<void> {
    const { error } = await this.supabase
      .from('User')
      .delete()
      .eq('user_id', user_id);

    if (error) throw error;
  }

  private async sendConfirmationEmail(email: string): Promise<void> {
    const { error } = await this.supabase.auth.updateUser({
      email
    });

    if (error) throw error;
  }
}