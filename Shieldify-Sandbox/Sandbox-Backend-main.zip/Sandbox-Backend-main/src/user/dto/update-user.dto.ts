export class UpdateUserDto {
  field: 'email' | 'username' | 'password' | 'avatar';
  value: string;
}