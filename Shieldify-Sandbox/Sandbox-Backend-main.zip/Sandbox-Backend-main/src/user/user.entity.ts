export class User {
    user_id: string;
    email: string;
    username: string;
    password: string;
    avatar: string;
  }