export const connection: Connection = {
    CONNECTION_SRTING: 'postgresql://postgres.axcqijvsigswapbpsdyp:5MjNOakUmxatNXsb@aws-0-us-west-1.pooler.supabase.com:6543/postgres',
    DB: 'postgres',
    DBNAME: 'postgres',
};

export type Connection = {
    CONNECTION_SRTING: string;
    DB: string;
    DBNAME: string;
}