import { Module } from '@nestjs/common';
import { RepositoryService } from './repository.service';
import { RepositoryController } from './repository.controller';
import { SonarCloudService } from './SonarCloudService';

@Module({
  controllers: [RepositoryController],
  providers: [RepositoryService, SonarCloudService],
  exports: [RepositoryService],
})
export class RepositoryModule {}