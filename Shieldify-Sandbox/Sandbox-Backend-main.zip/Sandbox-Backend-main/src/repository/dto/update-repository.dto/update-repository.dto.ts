import { PartialType } from '@nestjs/mapped-types';
import { CreateRepositoryDto } from '../create-repository.dto/create-repository.dto';
import { IsString, IsOptional, IsUrl } from 'class-validator';

export class UpdateRepositoryDto extends PartialType(CreateRepositoryDto) {
  @IsUrl()
  @IsOptional()
  github_url?: string;

  @IsString()
  @IsOptional()
  githubToken?: string;

  @IsString()
  @IsOptional()
  sonarqube_project_key?: string; // This should match your database column name
}