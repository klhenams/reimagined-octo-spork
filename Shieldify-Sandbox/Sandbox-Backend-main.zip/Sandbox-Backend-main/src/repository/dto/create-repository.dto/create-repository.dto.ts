import { IsString, IsOptional, IsUrl } from 'class-validator';

export class CreateRepositoryDto {
  @IsString()
  name: string;

  @IsString()
  @IsOptional()
  description?: string;

  @IsString()
  @IsOptional()
  sandboxId?: string;

  @IsString()
  sonarqubeProjectKey: string;

  @IsUrl()
  @IsOptional()
  github_url?: string;

  @IsString()
  @IsOptional()
  githubToken: string;
}