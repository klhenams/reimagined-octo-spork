import { Sandbox } from '../../../sandbox/entities/sandbox.entity';
import { User } from '../../../user/user.entity';

export class Repository {
  id: string;
  userId: string;
  name: string;
  description?: string;
  sandboxId?: string;
  sonarqube_project_key: string;
  sonarqubeToken?: string;
  github_url?: string;
  githubToken?: string;
  createdAt: Date;
  updatedAt: Date;
  user?: User;
  sandbox?: Sandbox;
}