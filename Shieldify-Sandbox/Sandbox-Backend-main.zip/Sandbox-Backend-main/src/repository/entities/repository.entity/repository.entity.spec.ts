import { RepositoryEntity } from './repository.entity';

describe('RepositoryEntity', () => {
  it('should be defined', () => {
    expect(new RepositoryEntity()).toBeDefined();
  });
});
