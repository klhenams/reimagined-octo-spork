import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Req, BadRequestException } from '@nestjs/common';
import { RepositoryService } from './repository.service';
import { CreateRepositoryDto } from '../repository/dto/create-repository.dto/create-repository.dto';
import { UpdateRepositoryDto } from '../repository/dto/update-repository.dto/update-repository.dto';
import { AuthGuard } from '@nestjs/passport';

@Controller('repository')
@UseGuards(AuthGuard('jwt'))
export class RepositoryController {
  constructor(private readonly repositoryService: RepositoryService) {}

  @Post()
  async create(@Req() req, @Body() createRepositoryDto: CreateRepositoryDto) {
    console.log('User:', req.user); // Log the user object
    if (!req.user || !req.user.userId) {
      throw new BadRequestException('User ID is required');
    }
    return this.repositoryService.create(req.user.userId, createRepositoryDto);
  }

  @Get()
  async findAll(@Req() req) {
    console.log('User:', req.user); // Log the user object
    return this.repositoryService.findAll(req.user.userId);
  }

  @Get(':id')
  async findOne(@Param('id') id: string, @Req() req) {
    console.log('User:', req.user); // Log the user object
    if (!id) {
      throw new BadRequestException('Repository ID is required');
    }
    return this.repositoryService.findOne(id, req.user.userId);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Req() req, @Body() updateRepositoryDto: UpdateRepositoryDto) {
    console.log('User:', req.user); // Log the user object
    if (!id) {
      throw new BadRequestException('Repository ID is required');
    }
    return this.repositoryService.update(id, req.user.userId, updateRepositoryDto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string, @Req() req, @Body('projectKey') projectKey: string) {
    console.log('User:', req.user); // Log the user object
    if (!id) {
      throw new BadRequestException('Repository ID and project key are required');
    }
    return this.repositoryService.remove(id, req.user.userId);
  }
}