import { Repository } from '../entities/repository.entity/repository.entity';
import { CreateRepositoryDto } from '../dto/create-repository.dto/create-repository.dto';
import { UpdateRepositoryDto } from '../dto/update-repository.dto/update-repository.dto';

export interface IRepositoryService {
  create(userId: string, createRepositoryDto: CreateRepositoryDto): Promise<Repository>;
  findAll(userId: string): Promise<Repository[]>;
  findOne(id: string, userId: string): Promise<Repository>;
  update(id: string, userId: string, updateRepositoryDto: UpdateRepositoryDto): Promise<Repository>;
  remove(id: string, userId: string, projectKey: string): Promise<void>
}
