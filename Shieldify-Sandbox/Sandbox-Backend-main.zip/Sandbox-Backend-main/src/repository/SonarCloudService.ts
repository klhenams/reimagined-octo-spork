import { Injectable, BadRequestException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios, { AxiosInstance } from 'axios';

@Injectable()
export class SonarCloudService {
  private readonly sonarCloudUrl: string;
  private readonly sonarToken: string;
  private readonly sonarOrganization: string;
  private readonly axiosInstance: AxiosInstance;
  private readonly logger = new Logger(SonarCloudService.name);

  constructor(private configService: ConfigService) {
    this.sonarCloudUrl = this.configService.get<string>('SONAR_CLOUD_URL');
    this.sonarToken = this.configService.get<string>('SONAR_TOKEN');
    this.sonarOrganization = this.configService.get<string>('SONAR_ORGANIZATION');
    
    if (!this.sonarCloudUrl || !this.sonarToken || !this.sonarOrganization) {
      throw new Error('SonarCloud URL, token, or organization is missing');
    }

    this.axiosInstance = axios.create({
      baseURL: this.sonarCloudUrl,
      headers: {
        'Authorization': `Bearer ${this.sonarToken}`,
        'Accept': 'application/json'
      }
    });

    this.logger.log(`SonarCloud URL: ${this.sonarCloudUrl}`);
    this.logger.log(`SonarCloud Token (first 5 chars): ${this.sonarToken.substring(0, 5)}...`);
    this.logger.log(`SonarCloud Organization: ${this.sonarOrganization}`);
    
    this.checkSonarCloudConnection();
  }

  async checkSonarCloudConnection(): Promise<void> {
    try {
      const response = await this.axiosInstance.get('/api/system/status');
      this.logger.log(`SonarCloud connection test successful: ${JSON.stringify(response.data)}`);
    } catch (error) {
      this.logger.error('Error checking SonarCloud connection:', error.response ? error.response.data : error.message);
    }
  }

  async createProject(key: string, name: string): Promise<string> {
    try {
      this.logger.log(`Creating SonarCloud project: ${key}`);
      
      const projectExists = await this.checkProjectExists(key);
      if (projectExists) {
        this.logger.log(`Project ${key} already exists. Skipping creation.`);
        return key;
      }

      const createProjectResponse = await this.axiosInstance.post(
        '/api/projects/create',
        `name=${encodeURIComponent(name)}&project=${encodeURIComponent(key)}&organization=${encodeURIComponent(this.sonarOrganization)}&visibility=public`
      );

      this.logger.log(`SonarCloud project creation response status: ${createProjectResponse.status}`);
      this.logger.log(`SonarCloud project creation response data: ${JSON.stringify(createProjectResponse.data)}`);
  
      if (createProjectResponse.status !== 200) {
        throw new Error(`Failed to create SonarCloud project: ${createProjectResponse.statusText}`);
      }
  
      this.logger.log(`SonarCloud project created successfully: ${key}`);

      const projectExistsAfterCreation = await this.checkProjectExists(key);
      this.logger.log(`Project exists after creation: ${projectExistsAfterCreation}`);
      
      const projectDetails = await this.getProject(key);
      this.logger.log(`Project details: ${JSON.stringify(projectDetails)}`);
      
      return key;
    } catch (error) {
      if (error.response) {
        this.logger.error('Error in createProject:', error.response.data, `Status: ${error.response.status}`);
      } else {
        this.logger.error('Error in createProject:', error.message);
      }
      throw new BadRequestException(`Failed to create SonarCloud project: ${error.message}`);
    }
  }

  private async checkProjectExists(key: string): Promise<boolean> {
    try {
      const response = await this.axiosInstance.get(
        `/api/projects/search?projects=${encodeURIComponent(key)}&organization=${encodeURIComponent(this.sonarOrganization)}`
      );
      
      return response.data.components && response.data.components.length > 0;
    } catch (error) {
      this.logger.error('Error checking if project exists:', error.response ? error.response.data : error.message);
      return false;
    }
  }

  async getProject(key: string): Promise<any> {
    try {
      const response = await this.axiosInstance.get(
        `/api/projects/search?projects=${encodeURIComponent(key)}&organization=${encodeURIComponent(this.sonarOrganization)}`
      );
      
      this.logger.log(`Get project response:`, response.data);
      return response.data;
    } catch (error) {
      this.logger.error('Error in getProject:', error.response ? error.response.data : error.message);
      throw new BadRequestException('Failed to get SonarCloud project');
    }
  }
}