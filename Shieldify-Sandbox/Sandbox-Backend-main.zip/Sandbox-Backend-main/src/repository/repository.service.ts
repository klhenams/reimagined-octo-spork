import { Injectable, BadRequestException, NotFoundException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { IRepositoryService } from '../repository/repository.interface/repository.interface.interface';
import { Repository } from '../repository/entities/repository.entity/repository.entity';
import { CreateRepositoryDto } from '../repository/dto/create-repository.dto/create-repository.dto';
import { UpdateRepositoryDto } from '../repository/dto/update-repository.dto/update-repository.dto';
import { SonarCloudService } from './SonarCloudService';

@Injectable()
export class RepositoryService implements IRepositoryService {
  private supabase: SupabaseClient;
  private readonly logger = new Logger(RepositoryService.name);

  constructor(
    private configService: ConfigService,
    private SonarCloudService: SonarCloudService
  ) {
    const supabaseUrl = this.configService.get<string>('SUPABASE_URL');
    const supabaseKey = this.configService.get<string>('SUPABASE_KEY');

    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Supabase URL or API key is missing');
    }

    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  async create(userId: string, createRepositoryDto: CreateRepositoryDto): Promise<Repository> {
    if (!userId) {
      throw new BadRequestException('User ID is required');
    }

    try {
      this.logger.log(`Creating repository for user: ${userId}`);
      
      const sonarqubeToken = await this.SonarCloudService.createProject(
        createRepositoryDto.sonarqubeProjectKey,
        createRepositoryDto.name,
      );

      const repositoryData = {
        name: createRepositoryDto.name,
        description: createRepositoryDto.description,
        sonarqube_project_key: createRepositoryDto.sonarqubeProjectKey,
        user_id: userId,
        sonarqube_token: sonarqubeToken,
        github_url: createRepositoryDto.github_url,
        github_token: createRepositoryDto.githubToken,
      };

      const { data, error } = await this.supabase
        .from('repository')
        .insert(repositoryData)
        .single();

      if (error) {
        this.logger.error('Error inserting repository to Supabase:', error);
        throw new BadRequestException('Failed to create repository');
      }

      this.logger.log(`Repository created successfully for user: ${userId}`);
      return data as Repository;
    } catch (error) {
      this.logger.error('Error creating repository:', error);
      throw new BadRequestException('Failed to create repository');
    }
  }

  async update(id: string, userId: string, updateRepositoryDto: UpdateRepositoryDto): Promise<Repository> {
    if (!id || !userId) {
      throw new BadRequestException('Repository ID and user ID are required');
    }

    try {
      const { data, error } = await this.supabase
        .from('repository')
        .update({
          ...updateRepositoryDto,
          github_url: updateRepositoryDto.github_url,
          github_token: updateRepositoryDto.githubToken,
          sonarqube_project_key: updateRepositoryDto.sonarqubeProjectKey, 
        })
        .eq('id', id)
        .eq('user_id', userId)
        .single();
  
      if (error) {
        this.logger.error('Error updating repository in Supabase:', error);
        throw new BadRequestException('Failed to update repository');
      }
  
      return data as Repository;
    } catch (error) {
      this.logger.error('Error updating repository:', error);
      throw new BadRequestException('Failed to update repository');
    }
  }

  async findAll(userId: string): Promise<Repository[]> {
    if (!userId) {
      throw new BadRequestException('User ID is required');
    }

    try {
      const { data, error } = await this.supabase
        .from('repository')
        .select('*')
        .eq('user_id', userId);

      if (error) {
        this.logger.error('Error fetching repositories from Supabase:', error);
        throw new BadRequestException('Failed to fetch repositories');
      }

      return data as Repository[];
    } catch (error) {
      this.logger.error('Error fetching repositories:', error);
      throw new BadRequestException('Failed to fetch repositories');
    }
  }

  async findOne(id: string, userId: string): Promise<Repository> {
    if (!id || !userId) {
      throw new BadRequestException('Repository ID and user ID are required');
    }

    try {
      const { data, error } = await this.supabase
        .from('repository')
        .select('*')
        .eq('id', id)
        .eq('user_id', userId)
        .single();

      if (error) {
        this.logger.error('Error fetching repository from Supabase:', error);
        throw new BadRequestException('Failed to fetch repository');
      }

      if (!data) {
        throw new NotFoundException('Repository not found');
      }

      return data as Repository;
    } catch (error) {
      this.logger.error('Error fetching repository:', error);
      throw new BadRequestException('Failed to fetch repository');
    }
  }

  async remove(id: string, userId: string): Promise<void> {
    if (!id || !userId) {
      throw new BadRequestException('Repository ID and user ID are required');
    }

    try {
      const { error: deleteError } = await this.supabase
        .from('repository')
        .delete()
        .eq('id', id)
        .eq('user_id', userId);

      if (deleteError) {
        this.logger.error('Error deleting repository from Supabase:', deleteError);
        throw new BadRequestException('Failed to delete repository');
      }
    } catch (error) {
      this.logger.error('Error deleting repository:', error);
      throw new BadRequestException('Failed to delete repository');
    }
  }
}