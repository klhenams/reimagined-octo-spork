import { IsNotEmpty, IsString, IsUUID, IsObject, IsOptional } from 'class-validator';

export class CreateSandboxDto {
  @IsNotEmpty()
  @IsString()
  projectKey: string;

  @IsNotEmpty()
  @IsUUID()
  repositoryId: string;

  @IsObject()
  @IsOptional()
  analysisResult?: any;
}