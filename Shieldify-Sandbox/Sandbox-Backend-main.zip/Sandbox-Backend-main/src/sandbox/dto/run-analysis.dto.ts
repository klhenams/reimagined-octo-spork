import { IsUUID, IsNotEmpty } from 'class-validator';

export class RunAnalysisDto {
  @IsUUID()
  @IsNotEmpty()
  repositoryId: string;

  @IsUUID()
  @IsNotEmpty()
  userId: string;
}