import { Process, Processor } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';
import { SandboxService } from './sandbox.service';

@Processor('analysis')
export class AnalysisConsumer {
  private readonly logger = new Logger(AnalysisConsumer.name);

  constructor(private readonly sandboxService: SandboxService) {}

  @Process('runAnalysis')
  async handleAnalysis(job: Job) {
    this.logger.debug(`Processing job ${job.id}`);
    try {
      const result = await this.sandboxService.runAnalysis(job.data);
      return result;
    } catch (error) {
      this.logger.error(`Failed to process job ${job.id}: ${error.message}`);
      throw error;
    }
  }
}