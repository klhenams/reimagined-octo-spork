import { Injectable, Logger, NotFoundException, InternalServerErrorException } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { ConfigService } from '@nestjs/config';
import { RunAnalysisDto } from './dto/run-analysis.dto';
import { Sandbox } from './entities/sandbox.entity';
import { SonarCloudService } from './SonarCloudService';
import { RepositoryService } from '../repository/repository.service';

@Injectable()
export class SandboxService {
  private supabase: SupabaseClient;
  private readonly logger = new Logger(SandboxService.name);

  constructor(
    private configService: ConfigService,
    private readonly sonarQubeService: SonarCloudService,
    private readonly repositoryService: RepositoryService
  ) {
    const supabaseUrl = this.configService.get('SUPABASE_URL');
    const supabaseKey = this.configService.get('SUPABASE_KEY');

    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Supabase URL or API key is missing');
    }

    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  async runAnalysis(runAnalysisDto: RunAnalysisDto): Promise<Sandbox> {
    const { repositoryId, userId } = runAnalysisDto;

    try {
      this.logger.log(`Starting analysis for repository: ${repositoryId}`);
      const repository = await this.repositoryService.findOne(repositoryId, userId);
      if (!repository) {
        this.logger.error(`Repository not found: ${repositoryId}`);
        throw new NotFoundException('Repository not found');
      }

      this.logger.log(`Repository found: ${repository.name}`);
      if (!repository.sonarqube_project_key) {
        repository.sonarqube_project_key = `${userId}_${repository.name}`.toLowerCase();
        await this.repositoryService.update(repositoryId, userId, { sonarqube_project_key: repository.sonarqube_project_key });
        this.logger.log(`Generated new SonarQube project key: ${repository.sonarqube_project_key}`);
      }

      this.logger.log(`Starting SonarQube analysis for project: ${repository.sonarqube_project_key}`);
      const analysisResult = await this.sonarQubeService.analyzeProject(
        repository.sonarqube_project_key,
        repository.github_url
      );

      this.logger.log(`Saving or updating analysis results in database`);
      
      // Check if a record already exists
      const { data: existingData, error: fetchError } = await this.supabase
        .from('sandbox')
        .select('*')
        .eq('repository_id', repositoryId)
        .single();

      if (fetchError && fetchError.code !== 'PGRST116') {
        throw fetchError;
      }

      let result;
      if (existingData) {
        // Update existing record
        const { data, error } = await this.supabase
          .from('sandbox')
          .update({
            project_key: repository.sonarqube_project_key,
            analysis_result: analysisResult,
            updated_at: new Date().toISOString(),
          })
          .eq('repository_id', repositoryId)
          .select()
          .single();

        if (error) throw error;
        result = data;
      } else {
        // Insert new record
        const { data, error } = await this.supabase
          .from('sandbox')
          .insert({
            project_key: repository.sonarqube_project_key,
            analysis_result: analysisResult,
            repository_id: repositoryId,
            updated_at: new Date().toISOString(),
          })
          .select()
          .single();

        if (error) throw error;
        result = data;
      }

      this.logger.log(`Analysis completed and saved/updated successfully`);
      return this.mapToSandboxEntity(result);
    } catch (error) {
      this.logger.error(`Failed to run analysis: ${error.message}`, error.stack);
      throw new InternalServerErrorException('Failed to run analysis');
    }
  }

  async findAll(): Promise<Sandbox[]> {
    try {
      const { data, error } = await this.supabase
        .from('sandbox')
        .select('*');

      if (error) throw error;

      return data.map(this.mapToSandboxEntity);
    } catch (error) {
      this.logger.error(`Failed to fetch all sandboxes: ${error.message}`, error.stack);
      throw new InternalServerErrorException('Failed to fetch all sandboxes');
    }
  }

  async findOne(id: string): Promise<Sandbox | null> {
    try {
      const { data, error } = await this.supabase
        .from('sandbox')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          return null; // No matching record found
        }
        throw error;
      }

      return this.mapToSandboxEntity(data);
    } catch (error) {
      this.logger.error(`Failed to fetch sandbox: ${error.message}`, error.stack);
      throw new InternalServerErrorException('Failed to fetch sandbox');
    }
  }

  private mapToSandboxEntity(data: any): Sandbox {
    return {
      id: data.id,
      project_key: data.project_key,
      analysis_result: data.analysis_result,
      created_at: new Date(data.created_at),
      updated_at: new Date(data.updated_at),
      repository_id: data.repository_id,
    };
  }
}