export interface AnalysisResult {
    projectKey: string;
    status: 'SUCCESS' | 'FAILED';
    qualityGate: {
      status: 'OK' | 'WARN' | 'ERROR';
      conditions: Array<{
        metric: string;
        operator: string;
        value: string;
        status: 'OK' | 'WARN' | 'ERROR';
      }>;
    };
    measures: Array<{
      metric: string;
      value: string;
    }>;
  }