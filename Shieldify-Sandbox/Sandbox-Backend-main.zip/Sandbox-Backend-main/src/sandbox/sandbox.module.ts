import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { ConfigModule } from '@nestjs/config';
import { SandboxController } from './sandbox.controller';
import { SandboxService } from './sandbox.service';
import { SonarCloudService } from './SonarCloudService';
import { RepositoryModule } from '../repository/repository.module';
import { DockerService } from './docker-service';

@Module({
  imports: [
    HttpModule,
    ConfigModule,
    RepositoryModule,
  ],
  controllers: [SandboxController],
  providers: [SandboxService, SonarCloudService, DockerService],
  exports: [SandboxService],
})
export class SandboxModule {}