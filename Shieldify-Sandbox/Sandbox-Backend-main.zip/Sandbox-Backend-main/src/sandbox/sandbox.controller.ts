import { Controller, Post, Body, Get, Param, UseGuards } from '@nestjs/common';
import { SandboxService } from './sandbox.service';
import { RunAnalysisDto } from './dto/run-analysis.dto';
import { Sandbox } from './entities/sandbox.entity';
import { AuthGuard } from '@nestjs/passport';

@Controller('sandbox')
@UseGuards(AuthGuard('jwt'))
export class SandboxController {
  constructor(private readonly sandboxService: SandboxService) {}

  @Post('analyze')
  async analyzeRepo(@Body() runAnalysisDto: RunAnalysisDto): Promise<{ sandbox: Sandbox; repositoryId: string }> {
    const sandbox = await this.sandboxService.runAnalysis(runAnalysisDto);
    return { sandbox, repositoryId: runAnalysisDto.repositoryId };
  }

  @Get()
  async findAll(): Promise<Sandbox[]> {
    return this.sandboxService.findAll();
  }

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<Sandbox | null> {
    return this.sandboxService.findOne(id);
  }
}