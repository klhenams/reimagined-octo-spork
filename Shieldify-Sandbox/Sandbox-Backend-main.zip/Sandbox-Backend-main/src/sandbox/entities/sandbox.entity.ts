export interface Sandbox {
  id: string;
  project_key: string;
  analysis_result: any;
  created_at: Date;
  updated_at: Date;
  repository_id: string;
}