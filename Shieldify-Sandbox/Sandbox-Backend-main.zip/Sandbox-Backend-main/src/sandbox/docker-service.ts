import { Injectable, Logger } from '@nestjs/common';
import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';

const execAsync = promisify(exec);

@Injectable()
export class DockerService {
  private readonly logger = new Logger(DockerService.name);

  async runAnalysisContainer(githubUrl: string, projectKey: string, organization: string): Promise<void> {
    const repoName = githubUrl.split('/').pop()?.replace('.git', '');
    const repoPath = path.join(__dirname, '..', '..', repoName || 'repo');

    try {
      // Clean up the directory if it exists
      if (fs.existsSync(repoPath)) {
        await execAsync(`rm -rf ${repoPath}`);
        this.logger.log(`Existing repository directory removed: ${repoPath}`);
      }

      // Clone the repository
      await execAsync(`git clone ${githubUrl} ${repoPath}`);
      this.logger.log(`Repository cloned: ${githubUrl}`);

      // Run SonarCloud analysis using the official SonarScanner Docker image
      const command = `
        docker run --rm \
        -e SONAR_TOKEN=${process.env.SONAR_TOKEN} \
        -v ${repoPath}:/usr/src \
        sonarsource/sonar-scanner-cli \
        -Dsonar.projectKey=${projectKey} \
        -Dsonar.organization=${organization} \
        -Dsonar.sources=/usr/src \
        -Dsonar.host.url=https://sonarcloud.io
      `;

      const { stdout, stderr } = await execAsync(command);
      this.logger.log(`SonarCloud analysis completed for project: ${projectKey}`);
      this.logger.log(`SonarCloud scan output: ${stdout}`);

      // Clean up cloned repository
      await execAsync(`rm -rf ${repoPath}`);
    } catch (error) {
      this.logger.error(`Failed to run analysis container: ${error.message}`);
      if (error.stdout) this.logger.error(`STDOUT: ${error.stdout}`);
      if (error.stderr) this.logger.error(`STDERR: ${error.stderr}`);
      throw error;
    }
  }
}