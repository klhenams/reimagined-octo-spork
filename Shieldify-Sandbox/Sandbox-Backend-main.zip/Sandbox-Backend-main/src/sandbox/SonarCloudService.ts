import { Injectable, Logger, InternalServerErrorException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DockerService } from './docker-service';
import axios, { AxiosInstance } from 'axios';

@Injectable()
export class SonarCloudService {
  private readonly logger = new Logger(SonarCloudService.name);
  private readonly sonarCloudUrl = 'https://sonarcloud.io';
  private readonly sonarToken: string;
  private readonly sonarOrganization: string;
  private readonly axiosInstance: AxiosInstance;

  constructor(
    private readonly configService: ConfigService,
    private readonly dockerService: DockerService
  ) {
    this.sonarToken = this.configService.get<string>('SONAR_TOKEN');
    this.sonarOrganization = this.configService.get<string>('SONAR_ORGANIZATION');

    if (!this.sonarToken || !this.sonarOrganization) {
      throw new Error('SonarCloud token or organization is not configured');
    }

    this.axiosInstance = axios.create({
      baseURL: this.sonarCloudUrl,
      headers: {
        'Authorization': `Bearer ${this.sonarToken}`,
        'Accept': 'application/json'
      }
    });

    this.checkConnection();
  }

  async checkConnection(): Promise<void> {
    try {
      const response = await this.axiosInstance.get('/api/system/status');
      this.logger.log(`SonarCloud connection test successful: ${JSON.stringify(response.data)}`);
    } catch (error) {
      this.logger.error('Error checking SonarCloud connection:', error.response ? error.response.data : error.message);
      throw new Error('Failed to connect to SonarCloud');
    }
  }

  async analyzeProject(projectKey: string, repoUrl: string): Promise<any> {
    if (!projectKey || !repoUrl) {
      throw new InternalServerErrorException('Project key or repository URL is undefined');
    }

    try {
      // Run the analysis using Docker
      await this.dockerService.runAnalysisContainer(repoUrl, projectKey, this.sonarOrganization);
      
      // Fetch the results from SonarCloud API
      const analysisResults = await this.fetchAnalysisResults(projectKey);
      
      return analysisResults;
    } catch (error) {
      this.logError(`Failed to analyze project ${projectKey}`, error);
      throw new InternalServerErrorException(`Analysis failed for project ${projectKey}: ${error.message}`);
    }
  }

  private async fetchAnalysisResults(projectKey: string): Promise<any> {
    try {
      const [metricsResponse, issuesResponse, hotspotResponse, qualityGateResponse] = await Promise.all([
        this.axiosInstance.get('/api/measures/component', {
          params: {
            component: projectKey,
            metricKeys: [
              'ncloc',
              'complexity',
              'cognitive_complexity',
              'duplicated_lines_density',
              'coverage',
              'line_coverage',
              'branch_coverage',
              'bugs',
              'vulnerabilities',
              'code_smells',
              'security_hotspots',
              'sqale_index',
              'sqale_debt_ratio',
              'reliability_rating',
              'security_rating',
              'test_success_density',
              'test_failures',
              'test_errors',
              'tests',
              'comment_lines_density',
              'files',
              'functions',
              'classes',
              'new_coverage',
              'new_line_coverage',
              'new_branch_coverage',
              'lines_to_cover',
              'uncovered_lines',
              'security_review_rating',
              'new_security_review_rating',
              'new_maintainability_rating',
              'new_reliability_rating',
              'confirmed_issues',
              'false_positive_issues',
              'open_issues',
              'reliability_remediation_effort',
              'security_remediation_effort'
            ].join(',')
          }
        }),
        this.axiosInstance.get('/api/issues/search', {
          params: {
            componentKeys: projectKey,
            resolved: 'false'
          }
        }),
        this.axiosInstance.get('/api/hotspots/search', {
          params: {
            projectKey: projectKey
          }
        }),
        this.axiosInstance.get('/api/qualitygates/project_status', {
          params: {
            projectKey: projectKey
          }
        })
      ]);

      return {
        metrics: this.processMetrics(metricsResponse.data),
        issues: this.processIssues(issuesResponse.data),
        hotspots: this.processHotspots(hotspotResponse.data),
        qualityGate: this.processQualityGate(qualityGateResponse.data)
      };
    } catch (error) {
      this.logError(`Failed to fetch analysis results for project ${projectKey}`, error);
      throw new InternalServerErrorException(`Failed to fetch analysis results: ${error.message}`);
    }
  }

  private processMetrics(metricsData: any): any {
    const processedMetrics: { [key: string]: number | string } = {};
    if (metricsData.component && Array.isArray(metricsData.component.measures)) {
      metricsData.component.measures.forEach((measure: any) => {
        processedMetrics[measure.metric] = measure.value;
      });
    }
    return processedMetrics;
  }

  private processIssues(issuesData: any): any {
    return {
      total: issuesData.total,
      issues: issuesData.issues.map((issue: any) => ({
        severity: issue.severity,
        component: issue.component,
        line: issue.line,
        message: issue.message,
        type: issue.type,
        effort: issue.effort
      }))
    };
  }

  private processHotspots(hotspotsData: any): any {
    return {
      total: hotspotsData.total,
      hotspots: hotspotsData.hotspots.map((hotspot: any) => ({
        vulnerabilityProbability: hotspot.vulnerabilityProbability,
        status: hotspot.status,
        component: hotspot.component,
        line: hotspot.line,
        message: hotspot.message,
        rule: hotspot.rule
      }))
    };
  }

  private processQualityGate(qualityGateData: any): any {
    if (qualityGateData && qualityGateData.projectStatus) {
      return {
        status: qualityGateData.projectStatus.status,
        conditions: qualityGateData.projectStatus.conditions.map((condition: any) => ({
          metric: condition.metricKey,
          operator: condition.comparator,
          value: condition.actualValue,
          status: condition.status,
          errorThreshold: condition.errorThreshold
        }))
      };
    }
    return null;
  }

  private logError(message: string, error: any): void {
    this.logger.error(message, error.stack);
    if (error.response) {
      this.logger.error(`Response status: ${error.response.status}`);
      this.logger.error(`Response data: ${JSON.stringify(error.response.data)}`);
    } else {
      this.logger.error(`Error message: ${error.message}`);
    }
  }
}