import { Controller, Post, Body, Get, Res, UseGuards, Logger, Req, HttpException, HttpStatus, Query, Headers, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { SignUpDto, SignInDto } from './dto/auth.dto';
import { ResetPasswordDto } from './dto/ForgotPasswordDto';
import { Response } from 'express';
import { AuthGuard } from './guards/auth.guards';

@Controller('auth')
export class AuthController {
  private readonly logger = new Logger(AuthController.name);

  constructor(private authService: AuthService) {}

  @Post('signup')
  async signUp(@Body() signUpDto: SignUpDto) {
    this.logger.log(`Received sign up request: ${JSON.stringify(signUpDto)}`);
    try {
      const result = await this.authService.signUp(signUpDto);
      this.logger.log('Sign up successful');
      return result;
    } catch (error) {
      this.logger.error(`Sign up error: ${error.message}`);
      if (error instanceof HttpException) {
        throw error;
      }
      throw new HttpException('Sign up failed', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Post('signin')
  async signIn(@Body() signInDto: SignInDto) {
    return this.authService.signIn(signInDto);
  }

  @Get('google')
  async signInWithGoogle(@Res() res: Response) {
    const { url } = await this.authService.signInWithGoogle();
    res.redirect(url);
  }

  @Get('github')
  async signInWithGithub(@Res() res: Response) {
    const { url } = await this.authService.signInWithGithub();
    res.redirect(url);
  }

  @Get('callback')
  async handleOAuthCallback(@Query('access_token') token: string) {
    return this.authService.handleOAuthCallback(token);
  }

  @Post('signout')
  @UseGuards(AuthGuard)
  async signOut(@Req() req) {
    this.logger.log('Signout attempt');
    const token = req.headers.authorization.split(' ')[1];
    this.logger.log(`Token extracted: ${token.substring(0, 10)}...`);
    try {
      const result = await this.authService.signOut(token);
      this.logger.log('Signout successful');
      return result;
    } catch (error) {
      this.logger.error(`Signout failed: ${error.message}`);
      throw error;
    }
  }

  @Post('forgot-password')
  async forgotPassword(@Body('email') email: string) {
    this.logger.log(`Received forgot password request for email: ${email}`);
    try {
      const result = await this.authService.forgotPassword(email);
      return result;
    } catch (error) {
      this.logger.error(`Forgot password error: ${error.message}`);
      throw new HttpException('Failed to process forgot password request', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Post('reset-password')
  async resetPassword(@Body() resetPasswordDto: ResetPasswordDto) {
    this.logger.log(`Received reset password request`);
    try {
      const result = await this.authService.resetPassword(resetPasswordDto);
      this.logger.log('Reset password request processed successfully');
      return result;
    } catch (error) {
      this.logger.error(`Reset password error: ${error.message}`);
      throw error;
    }
  }

  @Get('validate')
  async validateToken(@Headers('authorization') authHeader: string) {
    if (!authHeader) {
      throw new UnauthorizedException('Authorization header is missing');
    }
    const token = authHeader.split(' ')[1]; // Assuming Bearer token
    return this.authService.validateToken(token);
  }
}