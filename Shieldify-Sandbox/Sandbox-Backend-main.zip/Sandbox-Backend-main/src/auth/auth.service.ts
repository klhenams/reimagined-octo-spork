import { Injectable, Logger, BadRequestException, HttpException, HttpStatus, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { SignUpDto, SignInDto } from './dto/auth.dto';
import { ResetPasswordDto } from './dto/ForgotPasswordDto';
import { UserService } from '../user/user.service';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';

@Injectable()
export class AuthService {
  private supabase: SupabaseClient;
  private readonly logger = new Logger(AuthService.name);
  private jwtSecret: string;

  constructor(
    private configService: ConfigService,
    private userService: UserService,
  ) {
    const supabaseUrl = this.configService.get<string>('SUPABASE_URL');
    const supabaseKey = this.configService.get<string>('SUPABASE_KEY');
    this.jwtSecret = this.configService.get<string>('JWT_SECRET');

    if (!supabaseUrl || !supabaseKey || !this.jwtSecret) {
      throw new Error('Supabase URL, API key, or JWT secret is missing');
    }

    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  async signUp(signUpDto: SignUpDto) {
    this.logger.log(`Attempting to sign up user: ${JSON.stringify(signUpDto)}`);
   
    const { email, username, password } = signUpDto;
  
    if (!email || !username || !password) {
      this.logger.error('Invalid sign up data: missing required fields');
      throw new Error('Invalid sign up data: email, username, and password are required');
    }
  
    try {
      // Check if the email is already registered
      const { data: existingUser, error: findError } = await this.supabase
        .from('User')
        .select('user_id')
        .eq('email', email)
        .maybeSingle();
  
      if (findError) {
        this.logger.error(`Error checking existing user: ${findError.message}`);
        throw new Error(`Error checking existing user: ${findError.message}`);
      }
  
      if (existingUser) {
        this.logger.error(`User with email ${email} already exists`);
        throw new Error('User with this email already exists');
      }
  
      this.logger.log('Hashing password...');
      const hashedPassword = await bcrypt.hash(password, 10);
      this.logger.log('Password hashed successfully');
  
      this.logger.log('Signing up user with Supabase...');
      const { data, error } = await this.supabase.auth.signUp({
        email,
        password,
      });
  
      if (error) {
        this.logger.error(`Supabase sign up error: ${JSON.stringify(error)}`);
        throw new Error(`Supabase sign up failed: ${error.message}`);
      }
  
      if (!data || !data.user) {
        this.logger.error('User creation failed: no user data returned from Supabase');
        throw new Error('User creation failed: no user data returned');
      }
  
      this.logger.log('User signed up successfully with Supabase');
      const createUserDto = {
        user_id: data.user.id,
        email,
        username,
        password: hashedPassword,
      };
  
      this.logger.log('Creating user in database...');
      const newUser = await this.userService.create(createUserDto);
      this.logger.log('User created successfully in database');
      return newUser;
    } catch (error) {
      this.logger.error(`Sign up failed: ${error.message}`);
      if (error instanceof Error) {
        throw new Error(`Sign up failed: ${error.message}`);
      } else {
        throw new Error('An unknown error occurred during sign up');
      }
    }
  }

  async signIn(signInDto: SignInDto) {
    if (!signInDto.email || !signInDto.password) {
      throw new Error('Invalid sign in data');
    }

    try {
      const { data, error } = await this.supabase.auth.signInWithPassword({
        email: signInDto.email,
        password: signInDto.password,
      });

      if (error) {
        throw error;
      }
      return {
        user: data.user,
        session: data.session,
        access_token: data.session?.access_token,
      };
    } catch (error) {
      throw new Error(`Sign in failed: ${error.message}`);
    }
  }

  async signInWithGoogle() {
    try {
      const { data, error } = await this.supabase.auth.signInWithOAuth({
        provider: 'google',
      });

      if (error) {
        throw error;
      }

      return data;
    } catch (error) {
      throw new Error(`Sign in with Google failed: ${error.message}`);
    }
  }

  async signInWithGithub() {
    try {
      const { data, error } = await this.supabase.auth.signInWithOAuth({
        provider: 'github',
      });

      if (error) {
        throw error;
      }

      return data;
    } catch (error) {
      throw new Error(`Sign in with Github failed: ${error.message}`);
    }
  }

  async forgotPassword(email: string) {
    try {
      const { error } = await this.supabase.auth.resetPasswordForEmail(email, {
        redirectTo: 'http://your-frontend-domain/reset-password',
      });

      if (error) {
        this.logger.error(`Failed to send password reset email: ${error.message}`);
        throw new HttpException('Failed to send password reset email', HttpStatus.INTERNAL_SERVER_ERROR);
      }

      this.logger.log(`Password reset email sent to ${email}`);
      return { message: 'If an account exists with this email, a password reset link has been sent.' };
    } catch (error) {
      this.logger.error(`Failed to process forgot password request: ${error.message}`);
      throw new HttpException('Failed to process forgot password request', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async resetPassword(resetPasswordDto: ResetPasswordDto) {
    const { newPassword } = resetPasswordDto;

    try {
      const { error } = await this.supabase.auth.updateUser({
        password: newPassword,
      });

      if (error) {
        this.logger.error('Failed to update password');
        throw new BadRequestException('Failed to update password');
      }

      this.logger.log('Password updated successfully');
      return { message: 'Password updated successfully' };
    } catch (error) {
      this.logger.error(`Password reset failed: ${error.message}`);
      throw new HttpException(`Password reset failed: ${error.message}`, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async handleOAuthCallback(token: string) {
    try {
      const {
        data: { user },
        error,
      } = await this.supabase.auth.getUser(token);

      if (error) {
        throw error;
      }

      if (user) {
        // Use the new method to find the user by token
        const existingUser = await this.userService.findOneByToken(token);

        if (!existingUser) {
          // If the user doesn't exist, create a new entry in your User table
          const createUserDto = {
            user_id: user.id,
            email: user.email,
            username: user.user_metadata.full_name || user.email.split('@')[0],
            password: '', // You might want to generate a random password here
          };

          await this.userService.create(createUserDto);
        }

        return user;
      } else {
        throw new Error('User not found');
      }
    } catch (error) {
      throw new Error(`OAuth callback handling failed: ${error.message}`);
    }
  }

  async signOut(token: string) {
    try {
      const { error } = await this.supabase.auth.signOut();
      if (error) throw error;
      return { message: 'Signed out successfully' };
    } catch (error) {
      throw new UnauthorizedException('Failed to sign out');
    }
  }

  async validateToken(token: string) {
    try {
      const { data, error } = await this.supabase.auth.getUser(token);
      if (error) throw error;
  
      // Retrieve the user details from the User table
      const user_id = data.user.id;
      const { data: userData, error: userError } = await this.supabase
        .from('User')
        .select('*')
        .eq('user_id', user_id)
        .single();
  
      if (userError) throw userError;
  
      return userData;
    } catch (error) {
      throw new UnauthorizedException('Invalid token');
    }
  }
}