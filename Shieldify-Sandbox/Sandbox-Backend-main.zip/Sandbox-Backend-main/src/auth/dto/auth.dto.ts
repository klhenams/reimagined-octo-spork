export class SignUpDto {
  email: string;
  password: string;
  username: string;
}

export class SignInDto {
  email: string;
  username: string;
  password: string;
}