import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtStrategy } from './stratagies/jwt.strategy';
import { UserModule } from '../user/user.module';
import {UserService} from '../user/user.service'

@Module({
  imports: [
    PassportModule,
    JwtModule.registerAsync({
      imports: [ConfigModule,UserModule],
    /**
     * Returns an object with a secret and signOptions based on the provided ConfigService.
     *
     * @param {ConfigService} configService - The ConfigService instance to retrieve the JWT_SECRET from.
     * @return {Promise<{secret: string, signOptions: {expiresIn: string}}>} An object with the secret and signOptions.
     */
      useFactory: async (configService: ConfigService) => ({
        secret: configService.get<string>('JWT_SECRET'),
        signOptions: { expiresIn: '1h' },
      }),
      inject: [ConfigService],
    }),
    ConfigModule, 
  ],
  providers: [AuthService, JwtStrategy,UserService],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {}