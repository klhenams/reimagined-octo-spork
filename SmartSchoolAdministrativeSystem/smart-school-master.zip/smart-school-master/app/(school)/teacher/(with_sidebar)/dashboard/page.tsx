export default function TeacherDashboardPage(){
    return <div>This is the teacher dashboard</div>
}