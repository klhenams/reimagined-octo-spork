import PersonListSkeleton from "@/app/(school)/_components/skeleton/personListSkeleton";

export default function Loading(){
    
    return (
        <PersonListSkeleton/>
    )
}