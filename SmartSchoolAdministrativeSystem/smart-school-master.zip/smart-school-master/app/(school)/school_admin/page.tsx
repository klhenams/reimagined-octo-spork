import { redirect } from "next/navigation";

export default function SchoolAdminMainPage(){
    redirect("/school_admin/dashboard")
}