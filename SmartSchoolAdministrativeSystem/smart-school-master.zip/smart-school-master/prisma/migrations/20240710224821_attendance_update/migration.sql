-- AlterTable
ALTER TABLE "Attendance" ALTER COLUMN "meeting" SET DEFAULT 1;
