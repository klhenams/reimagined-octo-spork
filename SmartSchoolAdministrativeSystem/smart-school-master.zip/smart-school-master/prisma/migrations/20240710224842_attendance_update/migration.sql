-- AlterTable
ALTER TABLE "Attendance" ALTER COLUMN "meeting" DROP DEFAULT;
