-- AlterTable
ALTER TABLE "Student" ADD COLUMN     "phone_number" TEXT NOT NULL DEFAULT '+233123456789';
