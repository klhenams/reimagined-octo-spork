-- AlterTable
ALTER TABLE "Grade" ADD COLUMN     "title" TEXT NOT NULL DEFAULT 'examination';
