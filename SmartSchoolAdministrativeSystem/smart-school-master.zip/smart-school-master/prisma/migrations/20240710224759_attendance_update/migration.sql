-- AlterTable
ALTER TABLE "Attendance" ADD COLUMN     "meeting" INTEGER NOT NULL DEFAULT 0;
