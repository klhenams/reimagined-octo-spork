-- AlterTable
ALTER TABLE "Teacher" ALTER COLUMN "phone_number" DROP NOT NULL,
ALTER COLUMN "phone_number" DROP DEFAULT;
