/*
  Warnings:

  - You are about to drop the column `semester` on the `Grade` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Grade" DROP COLUMN "semester";
