-- AlterTable
ALTER TABLE "Grade" ALTER COLUMN "schoolId" DROP DEFAULT;
