export type ServerActionReturnModel = {
  success?: boolean;
  errorMessage?: string;
  data?: any;
};
