export class ML_API_ENDPOINTS {
  static studentGradePredict = "/student/predict";
  static studentGradePredictWithId = "/student/predict_with_id"
}
