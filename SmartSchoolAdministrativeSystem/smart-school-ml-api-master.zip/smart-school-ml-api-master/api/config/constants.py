import os

print(os.getcwd())
CONSTANTS = {
    "MODELS_PATH" : os.path.join(os.getcwd(), "api/models/")
}